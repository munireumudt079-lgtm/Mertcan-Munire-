MÜNİRE & MERTCAN – DÜĞÜN DAVETİYESİ

Bu klasördeki index.html, mobil uyumlu ve zarfa dokununca açılan Türkçe dijital davetiyedir.
Şarkı YouTube üzerinden eklenmiştir. Misafir zarfı açtığında oynatılmayı dener; bazı telefon/tarayıcılar otomatik sesi engellerse davetiyedeki “Müziği başlat / durdur” düğmesine dokunulabilir.

GITHUB PAGES'TE ÜCRETSİZ YAYINLAMA
1. GitHub hesabına giriş yap: https://github.com
2. New repository seç ve adını munire-mertcan-davetiyesi yap.
3. Repository görünürlüğünü Public seçip Create repository'ye bas.
4. Add file > Upload files ile bu klasördeki index.html dosyasını yükle ve Commit changes de.
5. Repository içinde Settings > Pages bölümüne gir.
6. Build and deployment altında Deploy from a branch seç.
7. Branch: main, folder: /(root) seçip Save'e bas.
8. Birkaç dakika sonra Pages bölümünde yayın bağlantısı görünür. Bağlantıyı WhatsApp'tan paylaşabilirsin.

Not: GitHub Pages ücretsiz statik site barındırmasıdır; public repository gerekir ve bağlantının sonsuza kadar kalacağı garanti edilemez. YouTube videosu, video sahibi tarafından kaldırılır veya gömülmesi kapatılırsa müzik çalmaz.
